/* typing.js: typed-text effect for the hero titles */
let timer;

export function startTyping(el, words) {
  clearTimeout(timer);
  if (!el || !words.length) return;
  // Respect reduced motion: show the first title without animation
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) { el.textContent = words[0]; return; }
  let w = 0, i = 0, deleting = false;
  const tick = () => {
    const word = words[w];
    el.textContent = word.slice(0, i);
    let delay = deleting ? 40 : 90;
    if (!deleting && i === word.length) { deleting = true; delay = 1400; }
    else if (deleting && i === 0) { deleting = false; w = (w + 1) % words.length; delay = 400; }
    i += deleting ? -1 : 1;
    timer = setTimeout(tick, delay);
  };
  tick();
}
