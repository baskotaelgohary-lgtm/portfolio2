/* i18n.js: language state, localStorage, and html lang/dir updates */
const KEY = 'lang';

/** Pick the right language from a {en, ar} object (falls back to English). */
export const t = (v, lang) =>
  v && typeof v === 'object' && !Array.isArray(v) ? (v[lang] ?? v.en ?? '') : (v ?? '');

export function getLang(content) {
  try { const s = localStorage.getItem(KEY); if (s === 'ar' || s === 'en') return s; } catch (e) {}
  return content.meta.defaultLang || 'en';
}

export function setLang(lang) {
  try { localStorage.setItem(KEY, lang); } catch (e) {}
}

/** Update <html lang dir>, the switch button, and every [data-i18n] element. */
export function applyStatic(content, lang) {
  const root = document.documentElement;
  root.lang = lang;
  root.dir = lang === 'ar' ? 'rtl' : 'ltr';
  const btn = document.getElementById('lang-switch');
  if (btn) btn.textContent = lang === 'ar' ? 'EN' : 'AR';
  document.querySelectorAll('[data-i18n]').forEach((el) => {
    const val = el.dataset.i18n.split('.').reduce((o, k) => (o ? o[k] : undefined), content);
    if (val) el.textContent = t(val, lang);
  });
}
