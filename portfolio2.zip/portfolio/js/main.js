/* main.js: loads content.json and wires everything together */
import { getLang, setLang, applyStatic, t } from './i18n.js';
import { renderAll, checkCv } from './render.js';
import { startTyping } from './typing.js';
import { initReveal } from './reveal.js';

document.documentElement.classList.add('js');
let content;

function draw() {
  const lang = getLang(content);
  applyStatic(content, lang);
  renderAll(content, lang);
  startTyping(document.getElementById('typed'), content.person.titles.map((x) => t(x, lang)));
  initReveal();
  checkCv(content.person.cv);
}

async function init() {
  try {
    const res = await fetch('data/content.json');
    if (!res.ok) throw new Error(res.status);
    content = await res.json();
  } catch (e) {
    document.getElementById('hero-content').innerHTML =
      '<p class="load-error mono">Could not load data/content.json. Run a local server (python -m http.server 8000) and open http://localhost:8000</p>';
    return;
  }
  draw();

  document.getElementById('lang-switch').addEventListener('click', () => {
    setLang(getLang(content) === 'ar' ? 'en' : 'ar');
    draw();
  });

  const toggle = document.querySelector('.nav__toggle');
  const links = document.getElementById('nav-links');
  toggle.addEventListener('click', () => {
    const open = links.classList.toggle('is-open');
    toggle.setAttribute('aria-expanded', open);
  });
  links.addEventListener('click', (e) => {
    if (e.target.tagName === 'A') { links.classList.remove('is-open'); toggle.setAttribute('aria-expanded', 'false'); }
  });
}
init();
