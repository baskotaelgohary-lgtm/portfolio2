/* render.js: builds every section from data/content.json */
import { t } from './i18n.js';

const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const $ = (id) => document.getElementById(id);
const title = (id, text) => `<h2 class="section-title reveal" id="${id}"><span class="mono prompt" aria-hidden="true">&gt;</span> ${esc(text)}</h2>`;

export function renderAll(c, lang) {
  const ui = c.ui, T = (v) => t(v, lang), p = c.person, k = c.contact;
  const wa = k.whatsapp ? `https://wa.me/${k.whatsapp}` : '';

  // ---------- Hero ----------
  const terminal = p.terminal.map((l) =>
    `<p><span class="prompt">$</span> ${esc(l.cmd)}</p><p class="out" dir="auto">${esc(T(l.out))}</p>`).join('');
  $('hero-content').innerHTML = `
    <div class="hero__grid">
      <div class="hero__text">
        <h1 id="hero-title">${esc(T(p.name))}</h1>
        <p class="hero__role mono" aria-hidden="true"><span id="typed"></span><span class="cursor"></span></p>
        <p class="sr-only">${p.titles.map(T).map(esc).join(', ')}</p>
        <p class="hero__intro">${esc(T(p.intro))}</p>
        <div class="cta-row">
          ${wa ? `<a class="btn btn--primary" href="${wa}" target="_blank" rel="noopener">${esc(T(ui.whatsapp))}</a>` : ''}
          ${k.github ? `<a class="btn" href="${esc(k.github)}" target="_blank" rel="noopener">${esc(T(ui.github))}</a>` : ''}
          <a class="btn" id="cv-btn" href="${esc(p.cv)}" download hidden>${esc(T(ui.cv))}</a>
        </div>
      </div>
      <div class="terminal" dir="ltr" aria-hidden="true">
        <div class="terminal__bar"><i></i><i></i><i></i><span class="mono">baskota@portfolio:~</span></div>
        <div class="terminal__body mono">${terminal}</div>
      </div>
    </div>`;

  // ---------- About ----------
  $('about-content').innerHTML = `
    ${title('about-title', T(c.nav.about))}
    <div class="about reveal">
      <p>${esc(T(c.about.bio))}</p>
      <ul class="facts">
        <li><span class="mono">${esc(T(ui.education))}</span>${esc(T(c.about.education))}</li>
        <li><span class="mono">${esc(T(c.nav.roadmap))}</span>${esc(T(c.about.goal))}</li>
      </ul>
    </div>`;

  // ---------- Skills ----------
  const level = { proficient: 100, learning: 55, planned: 15 };
  $('skills-content').innerHTML = `
    ${title('skills-title', T(c.nav.skills))}
    <div class="skills-grid">
      ${c.skills.map((g) => `
        <div class="skill-group reveal">
          <h3 class="mono">${esc(T(g.group))}</h3>
          <ul>${g.items.map((s) => `
            <li class="skill skill--${s.status}" style="--level:${level[s.status] ?? 0}%">
              <div class="skill__top"><span>${esc(s.name)}</span><span class="skill__status">${esc(T(ui.status[s.status]))}</span></div>
              <div class="skill__bar"><i></i></div>
            </li>`).join('')}
          </ul>
        </div>`).join('')}
    </div>`;

  // ---------- Roadmap ----------
  $('roadmap-content').innerHTML = `
    ${title('roadmap-title', T(c.nav.roadmap))}
    <ol class="timeline">
      ${c.roadmap.map((r) => `
        <li class="timeline__item timeline__item--${r.status} reveal">
          <span class="timeline__dot" aria-hidden="true"></span>
          <h3>${esc(T(r.title))} <span class="badge badge--${r.status}">${esc(T(ui.status[r.status]))}</span></h3>
          <p>${esc(T(r.text))}</p>
        </li>`).join('')}
    </ol>`;

  // ---------- Projects (works for 1 or many) ----------
  $('projects-content').innerHTML = `
    ${title('projects-title', T(c.nav.projects))}
    <div class="projects-grid ${c.projects.length === 1 ? 'projects-grid--single' : ''}">
      ${c.projects.map((pr) => `
        <article class="card reveal">
          <img class="card__img" src="${esc(pr.image)}" alt="${esc(T(pr.title))} screenshot" loading="lazy"
               onerror="this.onerror=null;this.src='assets/img/placeholder.svg';this.alt='${esc(T(ui.preview))}'">
          <div class="card__body">
            <h3>${esc(T(pr.title))}</h3>
            <p>${esc(T(pr.description))}</p>
            <ul class="tags">${pr.tech.map((x) => `<li class="mono">${esc(x)}</li>`).join('')}</ul>
            <div class="card__links">
              ${pr.github ? `<a href="${esc(pr.github)}" target="_blank" rel="noopener">${esc(T(ui.source))}</a>` : ''}
              ${pr.demo ? `<a href="${esc(pr.demo)}" target="_blank" rel="noopener">${esc(T(ui.demo))}</a>` : ''}
            </div>
          </div>
        </article>`).join('')}
    </div>`;

  // ---------- Contact ----------
  const links = [
    wa && [T(ui.whatsapp), wa],
    k.email && [T(ui.email), `mailto:${k.email}`],
    k.github && [T(ui.github), k.github],
    k.linkedin && [T(ui.linkedin), k.linkedin]
  ].filter(Boolean);
  const f = ui.form;
  $('contact-content').innerHTML = `
    ${title('contact-title', T(c.nav.contact))}
    <div class="contact reveal">
      <p>${esc(T(ui.contactIntro))}</p>
      <ul class="contact__links">${links.map(([n, h]) => `<li><a class="btn" href="${esc(h)}" ${h.startsWith('http') ? 'target="_blank" rel="noopener"' : ''}>${esc(n)}</a></li>`).join('')}</ul>
      ${k.formspreeId ? `
      <form class="form" id="contact-form" action="https://formspree.io/f/${esc(k.formspreeId)}" method="POST">
        <label>${esc(T(f.name))}<input name="name" required autocomplete="name"></label>
        <label>${esc(T(f.email))}<input name="email" type="email" required autocomplete="email"></label>
        <label>${esc(T(f.message))}<textarea name="message" rows="5" required></textarea></label>
        <button class="btn btn--primary" type="submit">${esc(T(f.send))}</button>
        <p class="form__status" role="status"></p>
      </form>` : ''}
    </div>`;
  const form = $('contact-form');
  if (form) form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const st = form.querySelector('.form__status');
    try {
      const r = await fetch(form.action, { method: 'POST', body: new FormData(form), headers: { Accept: 'application/json' } });
      if (!r.ok) throw new Error();
      form.reset(); st.textContent = T(f.sent);
    } catch (err) { st.textContent = T(f.error); }
  });

  // ---------- Footer + floating WhatsApp ----------
  $('footer-content').innerHTML = `<p>&copy; ${new Date().getFullYear()} ${esc(T(p.name))}. ${esc(T(ui.footer))}</p>`;
  const fl = $('wa-float');
  if (wa) { fl.href = wa; fl.hidden = false; }
}

/** Show the CV button only when the PDF actually exists. */
export async function checkCv(path) {
  const btn = $('cv-btn');
  if (!btn) return;
  try { const r = await fetch(path, { method: 'HEAD' }); if (r.ok) btn.hidden = false; } catch (e) { /* stays hidden */ }
}
